# Example Playbook

> This is a placeholder. Delete it once you've created your own playbooks.

## When To Use

When you want to see what a playbook page looks like. Replace this with
your first real reusable recipe.

## Preconditions

- The vault is initialized (you're reading this, so yes).

## Steps

1. **Read this page.** You're doing it now.
2. **Copy `_template.playbook.md`** to a new file in this folder.
3. **Fill it in** with a real recipe — something you do more than once
   and that has steps that future-you might forget.

## Failure Modes

- **If you skip writing playbooks:** future-you re-derives the same
  recipe from scratch every time. Cost: hours of repeated thinking.

## Variants

- None.

## Source Evidence

- This template's README.

## Related

- [[index]]
