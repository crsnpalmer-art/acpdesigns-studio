# [Playbook Name]

> Copy this file to `playbooks/<playbook-name>.md` and fill in.

## When To Use

[Trigger conditions. When does someone reach for this playbook? What
problem does it solve? Be specific so future-you can recognize the
situation quickly.]

## Preconditions

- [Required state of the system before running this playbook]
- [Required permissions, access, or tools]
- [Anything that should NOT be true (e.g. "do not run if the gateway
  is currently in maintenance mode")]

## Steps

1. **Step name.** What to do, with exact commands or actions.
   - Expected output / verification: how to know it worked.
   - If it fails: see Failure Modes below.
2. **Step name.** ...
3. ...

## Failure Modes

- **If [thing] happens:** [what to do]
- **If [thing] happens:** [what to do]

## Variants

- [Optional: variations for different contexts. E.g. "if running on
  staging instead of prod, swap step 3 for X."]

## Source Evidence

- [Where the steps came from. Past incident? Documentation? Conversation?
  Link them so future-you can re-derive if needed.]

## Related

- [[index]]
- (link to related project pages or playbooks)
