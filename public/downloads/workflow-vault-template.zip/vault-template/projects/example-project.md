# Example Project

> This is a placeholder. Delete it once you've created your own project pages.

## Current State

This is what an example project page looks like. Status: tentative.

Verified on: YYYY-MM-DD

## Active Plans

- (none — add a dated plan in `plans/` and link it here)

## Decisions

### 2026-01-01

- **Initialized the vault.**
  - Why: starting from the workflow-playbook template
  - Source: [README]

## Risks and Blockers

- **Risk: I haven't replaced this placeholder yet.** If I'm reading this
  in 6 months, the vault never got off the ground.

## Next Checkpoint

Replace this file with a real project page. Delete the placeholder.

## Related Pages

- [[index]]
- [[summary]]

## Source Evidence

- README.md — vault structure
