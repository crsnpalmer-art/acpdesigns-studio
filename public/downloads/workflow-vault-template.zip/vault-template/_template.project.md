# [Project Name]

> Copy this file to `projects/<your-project-name>.md` and fill in.

## Current State

[1-3 sentences describing where this project actually is right now. Not
where you want it to be — where it actually is. Include the date you last
verified this.]

Verified on: YYYY-MM-DD

## Active Plans

- [[plans/plan-YYYY-MM-DD-topic]] — short description (if applicable)

## Decisions

> Append-only. Don't rewrite past decisions. If a decision is reversed,
> add a new dated entry that says "supersedes the YYYY-MM-DD decision."

### YYYY-MM-DD

- **What was decided.** Short sentence.
  - Why: brief rationale
  - Source: link to evidence (call notes, transcript, message, file)

## Risks and Blockers

- **Risk: [short title]** — what could go wrong, and what would trigger it.
- **Blocker: [short title]** — what's stopping forward progress, who or what
  needs to act.

## Next Checkpoint

[What needs to happen next, by when, and what would mark this project as
"complete" or "ready for the next phase."]

## Related Pages

- [[index]]
- (link to other project pages, playbooks, or plans that relate to this work)

## Source Evidence

- [source-id-1] — what this source supports
- [source-id-2] — what this source supports
