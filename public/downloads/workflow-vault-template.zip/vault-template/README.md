# Workflow Planning Wiki — Starter Vault

This is a starter Obsidian vault matching the schema Carson Palmer uses for
his planning wiki. Open this folder in Obsidian (or any markdown editor) and
start filling it in.

## What's in here

- `index.md` — the main navigation page. Update this as you add new pages.
- `summary.md` — the fast-read overview. Update weekly.
- `log.md` — chronological append-only log of changes. Don't rewrite history.
- `CLAUDE.md` — instructions for AI assistants working with this vault.
- `projects/` — one page per system you're building (gateway, voice agent, etc.)
- `playbooks/` — reusable recipes for recurring tasks
- `plans/` — dated plan documents for specific work
- `_template.project.md`, `_template.playbook.md`, `_template.plan.md` — copy these to start new pages

## How to use it

1. Open this whole folder as an Obsidian vault (`File → Open Vault`).
2. Read `CLAUDE.md` to understand the schema.
3. Read `summary.md` and `index.md` as your starting points.
4. When you build something new, copy `_template.project.md` to `projects/<name>.md`.
5. When you make a decision worth remembering, append to `log.md` with the date.
6. Once a week, regenerate `summary.md` from your project pages.

## Why plain markdown

- Git-able. Diff-able. Future-proof.
- No vendor lock-in. Open in any editor.
- AI assistants can read and write it directly.
- Searchable with `grep` or any text editor's find-in-files.
- Version-controlled if you `git init` this folder.

## Recommended first steps

1. `cd` into this folder and run `git init` so you have version history.
2. Edit `CLAUDE.md` to describe your project context.
3. Pick one project (the one you're working on right now) and copy
   `_template.project.md` to `projects/<your-project>.md`. Fill it in.
4. Set a weekly calendar reminder to update `summary.md`.

That's the whole system. Everything else is just adding more pages to the
same shape.
