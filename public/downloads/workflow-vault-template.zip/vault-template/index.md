# Wiki Index

Primary navigation for this vault. Replace the placeholders below with your
real projects, playbooks, and plans as you create them.

## Projects

- [[projects/example-project]] — Replace this with your first project page.
- (add more as you create them)

## Playbooks

- [[playbooks/example-playbook]] — Replace this with your first playbook.
- (add more as you create them)

## Plans

- (none yet — add dated plans as you start them)

## Quick reads

- [[summary]] — Fast-read overview of project status
- [[log]] — Chronological log of changes
- [[CLAUDE]] — Schema for AI assistants

## How to use this index

- When you create a new page in `projects/`, `playbooks/`, or `plans/`, add a
  link here so it's discoverable.
- Don't put content in this file — it's just a navigation page.
- If this index gets long, consider grouping by status (Active / Paused /
  Archived).
