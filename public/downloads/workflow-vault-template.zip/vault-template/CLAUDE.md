# Wiki Schema

Purpose: maintain a persistent, interlinked wiki of planning knowledge for
[YOUR PROJECT/BUSINESS].

## Core Principles

1. Use sources, not guesses.
2. Prefer updating existing pages over creating duplicates.
3. Preserve history; append status updates instead of rewriting past decisions.
4. Keep provenance for every key claim.
5. Create links aggressively so knowledge compounds.

## Folder Contract

- `projects/` — one page per ongoing project or system
- `playbooks/` — reusable recipes for recurring tasks
- `plans/` — dated plan documents for specific work
- `index.md` — primary navigation
- `summary.md` — fast-read overview, regenerated weekly
- `log.md` — chronological append-only log of changes

## Page Types

### Project Pages (`projects/*.md`)

Required sections:
- `# Project Name`
- `## Current State`
- `## Active Plans`
- `## Decisions`
- `## Risks and Blockers`
- `## Next Checkpoint`
- `## Related Pages`

### Playbook Pages (`playbooks/*.md`)

Required sections:
- `# Playbook Name`
- `## When To Use`
- `## Preconditions`
- `## Steps`
- `## Failure Modes`
- `## Variants`
- `## Source Evidence`
- `## Related`

### Plan Pages (`plans/plan-YYYY-MM-DD-topic.md`)

Required sections:
- `# Title`
- `## Goal`
- `## Context`
- `## Constraints`
- `## Proposed Steps`
- `## Risks`
- `## Alternatives Considered`
- `## Status`
- `## Outcome` (add when known)
- `## Open Questions`
- `## Source Evidence`
- `## Links`

## Update Rules

- Never delete historical decisions unless explicitly told.
- If a new source contradicts older content, do not silently replace:
  - keep both,
  - mark the contradiction,
  - update status with "superseded by".
- Mark uncertain claims as `Status: tentative`.
- Keep pages concise but specific; avoid generic prose.

## Provenance Rules

Every non-trivial claim should cite a source in `## Source Evidence`:
- `- [source-id] short note about extracted fact`

## Output Style

- Prefer markdown links with relative paths.
- Keep each update deterministic and reproducible.
- Explicitly list what changed in `log.md`.
