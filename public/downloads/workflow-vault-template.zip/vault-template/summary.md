# Wiki Summary

> This file is the **fast-read path** into the wiki. Regenerate it weekly (or
> after major changes) by reading every project page and pulling the most
> recent decisions, open risks, and current status into one short document.

Last regenerated: YYYY-MM-DD

## Projects

- `[[projects/example-project]]` — Status: tentative. Replace this entry.

## Open Risks and Blockers (across projects)

(none yet — populate from project pages)

## Recent Decisions (last 14 days)

(none yet — append new decisions to project pages, then summarize here)

## Playbooks

- `[[playbooks/example-playbook]]` — Replace this entry.

## How to use this page

- **At the start of any work session**, read this first for orientation.
- **For specifics**, follow a wikilink to the relevant project / playbook / plan.
- **For a chronological view**, see `[[log]]`.
- **For the schema**, see `[[CLAUDE]]`.
