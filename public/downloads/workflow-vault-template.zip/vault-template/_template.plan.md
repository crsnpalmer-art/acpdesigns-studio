# Plan: [Topic]

> Save this file as `plans/plan-YYYY-MM-DD-topic.md`.

Date: YYYY-MM-DD

## Goal

[One sentence. What does success look like?]

## Context

[Why are we doing this now? What changed? What's the trigger?]

## Constraints

- [What can't change?]
- [What's the deadline, if any?]
- [What resources are available?]

## Proposed Steps

1. [First action]
2. [Second action]
3. ...

## Risks

- **Risk:** [thing that could go wrong]. Mitigation: [how to handle it]

## Alternatives Considered

- **Alternative 1:** [description]. Rejected because [reason].
- **Alternative 2:** [description]. Rejected because [reason].

## Status

[Status: proposed | in-progress | complete | abandoned | superseded]

## Outcome

> Add this section when the plan is complete or abandoned. Be honest about
> what worked and what didn't.

## Open Questions

- [Questions you still need answers to]

## Source Evidence

- [Conversations, docs, prior plans this builds on]

## Links

- [[index]]
- [[projects/relevant-project]]
