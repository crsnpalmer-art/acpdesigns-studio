# Setup: Telegram bot in 5 minutes

Goal: end up with a bot token, a chat ID, and a Telegram conversation where
your script's messages land. After this, you fill the values into `.env`
and you're done with the Telegram side forever.

## Step 1 — Create the bot (2 min)

1. Open Telegram. Search for **`@BotFather`** (the verified one with a checkmark).
2. Open a chat with BotFather. Send `/newbot`.
3. BotFather asks for a **display name** — pick anything ("Morning Brief Bot").
4. BotFather asks for a **username** — must end in `bot` (e.g.
   `morning_brief_42_bot`).
5. BotFather replies with a token that looks like
   `123456789:ABC-DEF1234ghIkl-zyx57W2v1u123ew11`. **Copy this. Save it
   somewhere safe.** This is your `TG_BOT_TOKEN`.

## Step 2 — Activate the bot (30 sec)

A new bot can't message you until you message it first. So:

1. In Telegram, search for the username you just picked.
2. Open a chat with your bot.
3. Send any message ("hi" works).

## Step 3 — Get your chat ID (1 min)

This is the trickiest part because it's not in the UI anywhere.

1. In a browser, visit:

   ```
   https://api.telegram.org/bot<YOUR_TOKEN_HERE>/getUpdates
   ```

   Replace `<YOUR_TOKEN_HERE>` with the token from step 1, *without the
   angle brackets*.

2. You'll see a JSON response. Find the field `"chat":{"id": 12345678,…}`.
   That number is your `TG_CHAT_ID`. **Copy it. Save it.**

   - For DMs to yourself, the number is positive (e.g. `12345678`).
   - For group chats, it's a negative number starting with `-100` followed by 10–13 digits.

3. If `getUpdates` returns an empty `result` array, you forgot to send a
   message in step 2. Send one and reload the URL.

## Step 4 — Test from the command line (1 min)

```bash
curl -s "https://api.telegram.org/bot<YOUR_TOKEN>/sendMessage" \
  -H "content-type: application/json" \
  -d '{"chat_id": <YOUR_CHAT_ID>, "text": "hello from curl"}'
```

If a message arrives in your Telegram chat, you're done. Fill `TG_BOT_TOKEN`
and `TG_CHAT_ID` into your `.env`.

## Common problems

- **`getUpdates` shows old/stale messages.** Telegram only keeps recent
  updates. Send a fresh message and reload.
- **`/sendMessage` returns `chat not found`.** Either the chat ID is wrong,
  or you never started the conversation with the bot.
- **`401 Unauthorized`.** The token is wrong. Check for trailing whitespace
  when you pasted.
- **You want a group chat instead of DMs.** Add the bot to a group, send a
  message in the group mentioning the bot, then call `getUpdates`. Group
  chat IDs are negative.

## Going further

Later, if you want approval-style replies ("APPROVE", "DECLINE"), you'll
need to either poll `getUpdates` continuously or set a webhook. The
[playbook quickstart](https://acpdesigns.studio/systemsplaybook)
covers the polling approach. Webhooks are slightly more involved but
better for production.
