# Workflow Starter Pack

Everything you need to get the 30-minute quickstart running tonight. No
typing from a blank page — clone, fill in three keys, run one command.

## What's in here

| File | What it is |
|---|---|
| `morning-brief.py` | The working Python script from the playbook quickstart. Sends a daily AI brief to Telegram. |
| `setup-telegram-bot.md` | Step-by-step walkthrough for creating a bot and getting the IDs you need. |
| `.env.example` | Template for the three secrets you'll fill in (Anthropic key, bot token, chat ID). |
| `crontab.example` | The exact cron line to schedule the morning brief at 8 AM daily. |
| `com.you.morning-brief.plist.example` | Optional — macOS LaunchAgent version of the cron job, if you prefer launchd over cron. |
| `expand-recipes.md` | Three more example workflows you can copy after the morning brief works. |

## In what order

1. **Read** [`setup-telegram-bot.md`](setup-telegram-bot.md). Make a bot, get the
   chat ID. Takes 5 minutes.
2. **Sign up** for an Anthropic API key at `console.anthropic.com`. Add $5 of
   credit. Takes 5 minutes.
3. **Copy** `.env.example` to `.env` and fill in the three values you just
   collected.
4. **Test** the script: `set -a; source .env; set +a; python3 morning-brief.py`.
   You should see "sent." and a Telegram DM.
5. **Schedule** it. Either `crontab -e` and paste from `crontab.example`, or
   load the LaunchAgent plist for the macOS-native version.
6. **Read** [`expand-recipes.md`](expand-recipes.md) once your morning brief
   has run for a few days. Pick the next workflow.

## Sanity checklist before you blame the script

- Did you actually source the `.env`? (Try `echo $ANTHROPIC_API_KEY` — should
  print your key.)
- Is your bot token valid? (Visit
  `https://api.telegram.org/bot<YOUR_TOKEN>/getMe` — should return JSON, not
  an error.)
- Does the chat ID match where you sent your test message? (Numbers vs.
  negative numbers matter — group chats are negative, DMs are positive.)
- Did you actually start a conversation with your bot before testing?
  (The bot can't DM you until you message it once.)

## Going deeper

Once the morning brief is running and feels useful, see the
[playbook](https://acpdesigns.studio/systemsplaybook) on the public site
for what to build next. The starter pack handles night one. The playbook
handles month one and beyond.
