#!/usr/bin/env python3
"""
morning-brief.py

Sends a daily AI-generated summary to your Telegram bot.

Required env vars (load from .env):
    ANTHROPIC_API_KEY  — get at console.anthropic.com
    TG_BOT_TOKEN       — get from @BotFather on Telegram
    TG_CHAT_ID         — your chat ID (see setup-telegram-bot.md)

Optional env vars:
    BRIEF_PROMPT       — override the prompt with your own
    CLAUDE_MODEL       — override the model (default: claude-haiku-4-5)
"""

import datetime as _dt
import json
import os
import sys
from urllib import request as http
from urllib.error import HTTPError, URLError


def env(name, default=None, required=False):
    val = os.environ.get(name, default)
    if required and not val:
        print(f"error: {name} is not set. See .env.example.", file=sys.stderr)
        sys.exit(2)
    return val


ANTHROPIC_KEY = env("ANTHROPIC_API_KEY", required=True)
TG_TOKEN = env("TG_BOT_TOKEN", required=True)
TG_CHAT_ID = env("TG_CHAT_ID", required=True)
MODEL = env("CLAUDE_MODEL", default="claude-haiku-4-5")

DEFAULT_PROMPT = (
    "Give me a 5-bullet morning brief. Today is "
    + _dt.date.today().isoformat()
    + ". "
    + "Cover: top news worth knowing, one practical thing to think about today, "
    + "and one specific question I should answer for myself. Be specific, no fluff."
)
PROMPT = env("BRIEF_PROMPT", default=DEFAULT_PROMPT)


def post_json(url, body, headers):
    req = http.Request(url, data=json.dumps(body).encode(), headers=headers)
    try:
        with http.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())
    except HTTPError as e:
        print(f"HTTP {e.code} from {url}: {e.read().decode()}", file=sys.stderr)
        sys.exit(1)
    except URLError as e:
        print(f"network error talking to {url}: {e}", file=sys.stderr)
        sys.exit(1)


# 1. Ask Claude for the morning summary
data = post_json(
    "https://api.anthropic.com/v1/messages",
    {
        "model": MODEL,
        "max_tokens": 600,
        "messages": [{"role": "user", "content": PROMPT}],
    },
    {
        "x-api-key": ANTHROPIC_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    },
)
text = data["content"][0]["text"]

# 2. Send it to Telegram
post_json(
    f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage",
    {
        "chat_id": int(TG_CHAT_ID),
        "text": "*Morning brief*\n\n" + text,
        "parse_mode": "Markdown",
    },
    {"content-type": "application/json"},
)
print("sent.")
