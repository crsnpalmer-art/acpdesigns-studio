# Three workflows to add after the morning brief works

The morning brief is the smallest possible "AI on a schedule" loop. Once
it's running and feels useful, here are three concrete next workflows
you can copy. Each one is a tiny variant on the morning-brief script —
different prompt, different schedule, sometimes a different data source.

---

## Recipe 1 — End-of-day inbox triage

**What it does:** Once a day at 5 PM, summarize emails you got today and
flag the 3 that need a reply tomorrow.

**Why it works:** Catches important threads before they age into the
"buried" pile. Most useful for people who treat email as a to-do list
they don't trust.

**How to build it:**

1. Copy `morning-brief.py` to `inbox-triage.py`.
2. Change the prompt to something like:

   ```
   It's 5 PM. Read the subject lines and first paragraphs of these
   emails I got today and tell me which 3 need a reply tomorrow.
   For each, give me one sentence on why it's important.

   [paste email subjects here, or read them via API]
   ```

3. Schedule for `0 17 * * 1-5` (5 PM weekdays).

**Where it gets interesting:** When you replace the manual paste with a
Gmail API call. That's covered in the
[playbook Build page](https://acpdesigns.studio/systemsplaybook-build).

---

## Recipe 2 — Weekly "what did I do" summary

**What it does:** Every Friday at 5 PM, summarize the week from your
calendar entries and any notes you wrote, and tell you what you actually
got done.

**Why it works:** End-of-week reflection without having to think hard
about it. Especially valuable if you forget what you worked on by
Monday.

**How to build it:**

1. Copy `morning-brief.py` to `weekly-review.py`.
2. Add code to read your last 7 days of calendar events. (macOS:
   `osascript -e 'tell application "Calendar" to get events'`. Google
   Calendar API: see the prompts on the [playbook Build page](https://acpdesigns.studio/systemsplaybook-build).)
3. Use a prompt like:

   ```
   Here are my calendar entries from the last 7 days:
   [paste]

   Tell me:
   - The 3 most important things I actually did
   - One thing I committed to that I haven't followed through on
   - One pattern worth noticing
   ```

4. Schedule for `0 17 * * 5` (5 PM Fridays).

---

## Recipe 3 — APPROVE-gated outbound message

**What it does:** Your script wants to send a message (an email reply,
a Slack DM, an SMS to a vendor). Instead of sending it directly, it
sends a *draft* to your Telegram, waits for you to reply "APPROVE",
then sends the real message.

**Why it works:** This is the actual pattern Carson uses for every
risky action in his system. Once you've built it once, you have a
template for any "AI drafts → human approves → action happens" loop.

**How to build it:**

1. Make a script that:
   - Drafts the message (Claude API call).
   - Sends the draft to your Telegram with a unique ID:
     `*DRAFT for review*\n\n{message}\n\nReply "APPROVE 42" to send.`
   - Polls `https://api.telegram.org/bot<TOKEN>/getUpdates` for messages
     matching `^APPROVE 42$` from your chat.
   - When it sees the approval, sends the real message via whatever
     channel (email API, Slack webhook, SMS via Twilio).
   - Stores the approved decision in a log file.

2. The polling approach is good enough for personal use. For production,
   set a Telegram webhook instead of polling (Telegram's Bot API docs
   for `setWebhook` cover it).

**The lesson:** Once you have approve-gated sends working, every other
"risky" workflow becomes the same pattern. Approve-gated AppFolio work
order, approve-gated Slack post, approve-gated calendar invite, etc.
The starter pack version of this is pure Python; the production version
in Hermes uses the agent runtime, but the user-facing UX is identical.

---

## How to think about adding workflows

A workflow is worth keeping if it **reduces** your inbox or your
to-do list. A workflow is worth deleting if it **adds** something for
you to read.

Carson's "things that broke" page has a list of workflows he built and
turned off. Read it before you build your fourth one. The pattern: jobs
that produce *more* things to read tend to fail. Jobs that produce
*fewer* things to do tend to succeed.

Pick your next workflow with that filter.
